<template>
    <div class="inner-page" v-if="$root.lang === 'RU'">
        <div class="page-header"><h1 class="page-title">Пользовательское соглашение</h1></div>
        <div class="formatted-text shadow"><p>Настоящее Соглашение определяет условия использования Пользователями
            материалов и сервисов сайта www.{{ $root.config.site_name.toLowerCase() }} (далее — «Сайт»).</p>
            <p>1. Общие условия<br>
                1.1. Настоящее Соглашение является публичной офертой. Получая
                доступ к материалам Сайта Пользователь считается присоединившимся
                к настоящему Соглашению.<br>
                1.2. Администрация Сайта вправе в любое время в одностороннем
                порядке изменять условия настоящего Соглашения. Такие изменения
                вступают в силу по истечении 3 (Трех) дней с момента размещения
                новой версии Соглашения на сайте. При несогласии Пользователя с
                внесенными изменениями он обязан отказаться от доступа к Сайту,
                прекратить использование материалов и сервисов Сайта.<br>
                2. Обязательства Пользователя<br>
                2.1. Использование материалов Сайта без согласия правообладателей
                не допускается. Для правомерного использования материалов Сайта
                необходимо заключение лицензионных договоров (получение лицензий)
                от Правообладателей.<br>
                2.2. При цитировании материалов Сайта, включая охраняемые
                авторские произведения, ссылка на Сайт обязательна<br>
                2.3. Пользователь предупрежден о том, что Администрация Сайта не
                несет ответственности за посещение и использование им внешних
                ресурсов, ссылки на которые могут содержаться на сайте.<br>
                2.4. Пользователь согласен с тем, что Администрация Сайта не несет
                ответственности и не имеет прямых или косвенных обязательств перед
                Пользователем в связи с любыми возможными или возникшими потерями
                или убытками, связанными с любым содержанием Сайта, регистрацией
                авторских прав и сведениями о такой регистрации, товарами или
                услугами, доступными на или полученными через внешние сайты или
                ресурсы либо иные контакты Пользователя, в которые он вступил,
                используя размещенную на Сайте информацию или ссылки на внешние
                ресурсы.<br>
                2.5. Пользователь принимает положение о том, что все материалы и
                сервисы Сайта или любая их часть могут сопровождаться рекламой.
                Пользователь согласен с тем, что Администрация Сайта не несет
                какой-либо ответственности и не имеет каких-либо обязательств в
                связи с такой рекламой.<br>
                3. Прочие условия<br>
                3.1. Ничто в Соглашении не может пониматься как установление между
                Пользователем и Администрации Сайта агентских отношений, отношений
                товарищества, отношений по совместной деятельности, отношений
                личного найма, либо каких-то иных отношений, прямо не
                предусмотренных Соглашением.<br>
                3.2. Признание судом какого-либо положения Соглашения
                недействительным или не подлежащим принудительному исполнению не
                влечет недействительности иных положений Соглашения.<br>
                3.3. Бездействие со стороны Администрации Сайта в случае нарушения
                кем-либо из Пользователей положений Соглашения не лишает
                Администрацию Сайта права предпринять позднее соответствующие
                действия в защиту своих интересов и защиту авторских прав на
                охраняемые в соответствии с законодательством материалы Сайта.<br>
                3.4. При пополнении баланса пользователи получают виртуальную
                валюту, которая рассчитывается в соответствии с внутренним курсом
                сайта, отображенном в поле для пополнения баланса.<br>
                3.5. При пополнении баланса пользователь гарантировано получает в
                свою собственность виртуальный предмет на сайте, который может
                использовать без каких либо ограничений.</p></div>
    </div>
    <div class="inner-page" v-else>
        <div class="page-header"><h1 class="page-title">TERMS OF SERVICE</h1></div>
        <div class="formatted-text shadow"><p>This Agreement defines the terms of use by Users of the site materials and
            services www.{{ $root.config.site_name.toLowerCase() }} (the "site").</p>
            <p>1. General conditions<br>
                1.1. This Agreement is a public offer. By accessing the materials of the Site, the User is considered to
                have acceded to this Agreement<br>
                1.2. The Site Administration has the right at any time to unilaterally change the terms of this
                Agreement. Such changes take effect after 3 (Three) days from the date of posting a new version of the
                Agreement on the site. If the User disagrees with the changes made, he is obliged to refuse access to
                the Site, stop using the materials and services of the Site.<br>
                2. Obligations of the User<br>
                2.1. Using the materials of the Site without the consent of the copyright holders is not allowed. For
                the legitimate use of the materials of the Site, it is necessary to conclude licensing agreements
                (obtaining licenses) from the Copyright Holders.<br>
                2.2. When quoting materials from the Site, including copyrighted works, a link to the Site is
                required.<br>
                2.3. The user is warned that the Site Administration is not responsible for visiting and using external
                resources, links to which may be contained on the site.<br>
                2.4. The User agrees that the Site Administration is not responsible and does not have direct or
                indirect obligations to the User in connection with any possible or resulting loss or loss associated
                with any content of the Site, copyright registration and information about such registration, goods or
                services, accessible on or received through external sites or resources or other contacts of the User
                into which he entered using information posted on the Site or links to external resources.<br>
                2.5. The user accepts the provision that all materials and services of the Site or any part thereof may
                be accompanied by advertising. The user agrees that the Site Administration does not bear any
                responsibility and does not have any obligations in connection with such advertising.<br>
                3. Other conditions<br>
                3.1. Nothing in the Agreement can be understood as the establishment between the User and the Site
                Administration of agent relations, partnership relations, joint business relations, personal hiring
                relations, or any other relations not expressly provided for in the Agreement.<br>
                3.2. Recognition by a court of a provision of the Agreement as invalid or not enforceable does not
                entail the invalidity of other provisions of the Agreement.<br>
                3.3. Inaction on the part of the Site Administration in case of violation by any of the Users of the
                provisions of the Agreement does not deprive the Site Administration of the right to take later
                appropriate actions to protect its interests and protect copyright on the Site materials protected in
                accordance with the law.<br>
                3.4. When depositing the balance, users receive a virtual currency, which is calculated in accordance
                with the internal site rate displayed in the field for depositing the balance.<br>
                3.5. When depositing the balance, the user is guaranteed to receive in his ownership a virtual item on
                the site that he can use without any restrictions.</p></div>
    </div>
</template>

<script>
    export default {}
</script>
